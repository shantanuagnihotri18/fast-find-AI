# Fast Find AI — beginner MVP

A Flask + SQLite lost-and-found app with private reports, basic text similarity, perceptual photo similarity, and a claim review flow.

## Important limitation
The current photo comparison uses perceptual hashes (pHash), which works best when photos are visually similar. It is **not** a semantic/deep-learning vision model. The text comparison uses TF-IDF and string similarity. Scores are suggestions only, never proof of ownership. A later upgrade can use CLIP image embeddings and sentence-transformers.

## Windows setup

1. Install Python 3.11 or 3.12 from https://www.python.org/downloads/ and enable "Add Python to PATH".
2. Open PowerShell in this folder.
3. Create and activate the virtual environment:

   ```powershell
   py -m venv venv
   .\venv\Scripts\Activate.ps1
   ```

4. Install dependencies:

   ```powershell
   python -m pip install --upgrade pip
   pip install -r requirements.txt
   ```

5. Start the app:

   ```powershell
   python app.py
   ```

6. Open http://127.0.0.1:5000 in your browser.

## Test the matching flow

- Register Account A and create a lost-item report.
- Open a private/incognito browser window, register Account B, and create a found-item report with similar details.
- Sign in as Account A and open Matches; send a claim with a unique ownership detail.
- Sign in as Account B and open Claims to review it.

## Security notes before public deployment

- Set a strong random `SECRET_KEY` environment variable. The default is development-only.
- Use HTTPS, CSRF protection (for example Flask-WTF), email verification, rate limiting, and malware/image validation before a public launch.
- Use production database and private object storage for deployment. Never place private uploads inside `static/`.
- Do not expose full identity-document images or sensitive numbers in reports.
- Claim approval is a manual workflow, not automated identity verification.
- Run with debug disabled in production; do not use Flask's development server for public deployment.
